package com.example.Untitled_8_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Untitled8SpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
