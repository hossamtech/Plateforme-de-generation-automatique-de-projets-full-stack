package com.example.Untitled_8_spring.dto;

import lombok.Data;

@Data
public class ArbitreDto {

    private Long idarbitre;
    private String nom;
    private String nationalite;
}
