package com.example.Untitled_8_spring.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.Untitled_8_spring.models.Arbitre;

public interface ArbitreRepository extends JpaRepository<Arbitre, Long> {
}
