package com.example.Untitled_8_spring.dto;

import java.util.List;
import lombok.Data;

@Data
public class EquipeDto {

    private Long idequipe;
    private String nomequipe;
    private String pays;
}
