package com.example.Untitled_8_spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Untitled8SpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(Untitled8SpringApplication.class, args);
	}

}
