export interface Equipe {
    idequipe: number;
    nomequipe: string;
    pays: string;
}
