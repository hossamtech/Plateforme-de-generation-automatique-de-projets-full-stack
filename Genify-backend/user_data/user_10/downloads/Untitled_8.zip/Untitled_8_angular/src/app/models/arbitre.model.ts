export interface Arbitre {
    idarbitre: number;
    nom: string;
    nationalite: string;
}
