export interface MenuItem {
    id?: any;
    label?: any;
    link?: string;
}
