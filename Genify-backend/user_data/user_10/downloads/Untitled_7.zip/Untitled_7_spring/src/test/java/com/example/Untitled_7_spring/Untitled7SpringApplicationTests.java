package com.example.Untitled_7_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Untitled7SpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
