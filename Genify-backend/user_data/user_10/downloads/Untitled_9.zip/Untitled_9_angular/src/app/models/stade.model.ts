export interface Stade {
    idstade: number;
    nomstade: string;
    ville: string;
}
