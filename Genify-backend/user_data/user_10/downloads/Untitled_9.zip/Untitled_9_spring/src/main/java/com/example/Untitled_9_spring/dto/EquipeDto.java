package com.example.Untitled_9_spring.dto;

import java.util.List;
import lombok.Data;

@Data
public class EquipeDto {

    private Long idequipe;
    private String nomequipe;
    private String pays;
}
