package com.example.Untitled_9_spring.dto;

import lombok.Data;

@Data
public class StadeDto {

    private Long idstade;
    private String nomstade;
    private String ville;
}
