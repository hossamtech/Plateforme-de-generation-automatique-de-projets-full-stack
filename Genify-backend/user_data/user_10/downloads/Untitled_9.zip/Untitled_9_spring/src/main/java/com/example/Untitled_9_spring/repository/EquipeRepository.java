package com.example.Untitled_9_spring.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.Untitled_9_spring.models.Equipe;

public interface EquipeRepository extends JpaRepository<Equipe, Long> {
}
