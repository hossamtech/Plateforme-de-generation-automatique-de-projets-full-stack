package com.example.Untitled_9_spring.dto;

import lombok.Data;

@Data
public class JoueurDto {

    private Long idjoueur;
    private String nomjoueur;
    private String poste;
    private Long Idequipe;
}
