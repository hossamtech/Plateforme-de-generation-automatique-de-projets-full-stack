package com.example.Untitled_9_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Untitled9SpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
