package com.example.Untitled_5_spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Untitled5SpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(Untitled5SpringApplication.class, args);
	}

}
