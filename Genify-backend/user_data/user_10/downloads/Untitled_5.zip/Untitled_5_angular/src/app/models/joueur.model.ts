export interface Joueur {
    idjoueur: number;
    nomjoueur: string;
    poste: string;
    equipeId: number;
}
