export interface Match {
    idmatch: number;
    datematch: Date;
    heurematch: Date;
    arbitreId: number;
    equipe1Id: number;
    equipe2Id: number;
    stadeId: number;
}
