export interface arbitre {
    idarbitre: number;
    nom: string;
    nationalite: string;
}
