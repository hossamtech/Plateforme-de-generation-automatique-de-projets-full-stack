export interface stade {
    idstade: number;
    nomstade: string;
    ville: string;
}
