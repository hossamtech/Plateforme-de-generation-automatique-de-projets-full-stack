export interface match {
    idmatch: number;
    datematch: Date;
    heurematch: Date;
    arbitreId: number;
    stadeId: number;
}
