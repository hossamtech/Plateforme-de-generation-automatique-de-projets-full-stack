export interface equipe {
    idequipe: number;
    nomequipe: string;
    pays: string;
}
