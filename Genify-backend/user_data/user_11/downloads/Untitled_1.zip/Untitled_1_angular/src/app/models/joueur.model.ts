export interface joueur {
    idjoueur: number;
    nomjoueur: string;
    poste: string;
    equipeId: number;
}
