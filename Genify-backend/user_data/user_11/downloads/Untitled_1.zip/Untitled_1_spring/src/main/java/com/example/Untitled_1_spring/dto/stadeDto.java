package com.example.Untitled_1_spring.dto;

import lombok.Data;

@Data
public class stadeDto {

    private Integer idStade;
    private String nomStade;
    private String ville;
}
