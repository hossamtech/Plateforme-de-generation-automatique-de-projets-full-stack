package com.example.Untitled_1_spring.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.Untitled_1_spring.models.match;

public interface matchRepository extends JpaRepository<match, Long> {
}
