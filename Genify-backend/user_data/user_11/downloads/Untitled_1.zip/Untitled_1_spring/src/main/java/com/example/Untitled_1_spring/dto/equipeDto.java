package com.example.Untitled_1_spring.dto;

import lombok.Data;

@Data
public class equipeDto {

    private Integer idEquipe;
    private String nomEquipe;
    private String pays;
}
