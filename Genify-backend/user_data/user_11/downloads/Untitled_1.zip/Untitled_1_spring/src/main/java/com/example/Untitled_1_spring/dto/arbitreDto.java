package com.example.Untitled_1_spring.dto;

import lombok.Data;

@Data
public class arbitreDto {

    private Integer idArbitre;
    private String nom;
    private String Nationalite;
}
