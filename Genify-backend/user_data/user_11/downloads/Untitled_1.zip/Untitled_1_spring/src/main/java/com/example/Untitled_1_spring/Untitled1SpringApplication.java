package com.example.Untitled_1_spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Untitled1SpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(Untitled1SpringApplication.class, args);
	}

}
