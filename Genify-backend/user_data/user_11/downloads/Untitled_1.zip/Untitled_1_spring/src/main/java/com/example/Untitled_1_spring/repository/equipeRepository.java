package com.example.Untitled_1_spring.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.Untitled_1_spring.models.equipe;

public interface equipeRepository extends JpaRepository<equipe, Long> {
}
